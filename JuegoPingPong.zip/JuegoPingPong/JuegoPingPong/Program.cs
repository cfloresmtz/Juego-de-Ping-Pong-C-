﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JuegoPingPong
{
    internal static class Program
    {
        public static frmMain frmMain = null;
       // public static frmPrimerVentana frmPrimerVentana = null;
        //public static frmPrimerVentana frmSegundaVentana = null;

        //public static frmPrimerVentana = null;
        //public static frmPrimerVentana = null;
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]

        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(frmMain = new frmMain());
        }
    }
}
