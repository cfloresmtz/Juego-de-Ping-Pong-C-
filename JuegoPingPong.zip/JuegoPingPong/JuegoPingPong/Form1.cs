﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JuegoPingPong
{
    public partial class frmMain : Form
    {
        public frmPrimerVentana frmPrimerVentana;
        public frmSegundaVentana frmSegundaVentana;


        public frmMain()
        {
           
        InitializeComponent();

            this.Size = new Size(950, 750);
            this.StartPosition = FormStartPosition.CenterScreen; //Centrar
            this.KeyPreview = true;

        }

        private void btnEmpezar_Click(object sender, EventArgs e)
        {
            if(frmPrimerVentana == null)
            {
                frmPrimerVentana = new frmPrimerVentana();
                frmPrimerVentana.MdiParent = this;
                
            }
            frmPrimerVentana.Show();
            if (frmSegundaVentana == null)
            {
                frmSegundaVentana = new frmSegundaVentana();
                frmSegundaVentana.MdiParent = this;

            }
            frmSegundaVentana.Show();

            frmPrimerVentana.Location = new Point(0, 0);
            frmSegundaVentana.Location = new Point(frmPrimerVentana.Width, 0);

            frmPrimerVentana.VentanaJugador2 = frmSegundaVentana;//Con esto accedo de la primera ventana a la segunda
            frmSegundaVentana.VentanaPrincipal = frmPrimerVentana;

            frmPrimerVentana.Focus();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            
            if (frmPrimerVentana != null && !frmPrimerVentana.IsDisposed)
            {
                if (keyData == Keys.W)
                {
                    frmPrimerVentana.MoverArriba();
                    return true; 
                }
                if (keyData == Keys.S)
                {
                    frmPrimerVentana.MoverAbajo();
                    return true;
                }
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void tspCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tspCerrar_MouseEnter(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void tspCerrar_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

    }
}
