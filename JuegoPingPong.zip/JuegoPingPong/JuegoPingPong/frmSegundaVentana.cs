﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JuegoPingPong
{
    public partial class frmSegundaVentana : Form
    {
        private Point PosicionInicial;
        public frmPrimerVentana VentanaPrincipal { get; set; }
        public frmSegundaVentana()
        {
            InitializeComponent();
            this.Size = new Size(464, 630);
            this.StartPosition = FormStartPosition.Manual;
            PosicionInicial = new Point(464, 0);
        }

       
        private void frmSegundaVentana_Move(object sender, EventArgs e)
        {
            if (this.Location != PosicionInicial)
                this.Location = PosicionInicial;
        }

        private void frmSegundaVentana_MouseMove(object sender, MouseEventArgs e)
        {
            pbPlayer2.Top = e.Location.Y;
            
        }

        public Rectangle ObtenerRaquetaJugador2()
        {
            return pbPlayer2.Bounds;
        }

        public void RecibirPelota(PictureBox pelota)
        {
            this.Controls.Add(pelota);

            
            pelota.Location = new Point(0, pelota.Top);

            pelota.BringToFront();
        }

        public void DevolverPelota(PictureBox Pelota)
        {
            this.Controls.Remove(Pelota);
            Pelota.Location = new Point(this.Width - Pelota.Width - 10, Pelota.Top);
            VentanaPrincipal.RecibirPelota(Pelota);
        }
    }
    
}
