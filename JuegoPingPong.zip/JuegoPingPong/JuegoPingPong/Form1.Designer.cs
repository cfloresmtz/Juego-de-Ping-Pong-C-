﻿namespace JuegoPingPong
{
    partial class frmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblJuego = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tspEmpezar = new System.Windows.Forms.ToolStripButton();
            this.tspCerrar = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblJuego
            // 
            this.lblJuego.AutoSize = true;
            this.lblJuego.BackColor = System.Drawing.Color.LawnGreen;
            this.lblJuego.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblJuego.Location = new System.Drawing.Point(325, 55);
            this.lblJuego.Name = "lblJuego";
            this.lblJuego.Size = new System.Drawing.Size(266, 31);
            this.lblJuego.TabIndex = 1;
            this.lblJuego.Text = "Juego de PingPong";
            this.lblJuego.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 0);
            this.label1.TabIndex = 5;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(461, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 0);
            this.label2.TabIndex = 6;
            this.label2.Text = "label2";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.Chartreuse;
            this.toolStrip1.BackgroundImage = global::JuegoPingPong.Properties.Resources.publico;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tspEmpezar,
            this.tspCerrar});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(934, 55);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "Juego de PingPong";
            // 
            // tspEmpezar
            // 
            this.tspEmpezar.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.tspEmpezar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tspEmpezar.Image = global::JuegoPingPong.Properties.Resources.ping_pong;
            this.tspEmpezar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tspEmpezar.Name = "tspEmpezar";
            this.tspEmpezar.Size = new System.Drawing.Size(80, 52);
            this.tspEmpezar.Text = "Empezar";
            this.tspEmpezar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tspEmpezar.Click += new System.EventHandler(this.btnEmpezar_Click);
            this.tspEmpezar.MouseEnter += new System.EventHandler(this.tspCerrar_MouseEnter);
            this.tspEmpezar.MouseLeave += new System.EventHandler(this.tspCerrar_MouseLeave);
            // 
            // tspCerrar
            // 
            this.tspCerrar.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tspCerrar.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.tspCerrar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tspCerrar.Image = global::JuegoPingPong.Properties.Resources._switch;
            this.tspCerrar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tspCerrar.Name = "tspCerrar";
            this.tspCerrar.Size = new System.Drawing.Size(60, 52);
            this.tspCerrar.Text = "Cerrar";
            this.tspCerrar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.tspCerrar.Click += new System.EventHandler(this.tspCerrar_Click);
            this.tspCerrar.MouseEnter += new System.EventHandler(this.tspCerrar_MouseEnter);
            this.tspCerrar.MouseLeave += new System.EventHandler(this.tspCerrar_MouseLeave);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(934, 711);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblJuego);
            this.Controls.Add(this.toolStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "Juego de Ping Pong";
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblJuego;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tspEmpezar;
        private System.Windows.Forms.ToolStripButton tspCerrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

