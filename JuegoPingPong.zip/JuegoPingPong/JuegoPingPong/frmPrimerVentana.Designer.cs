﻿namespace JuegoPingPong
{
    partial class frmPrimerVentana
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tmBola = new System.Windows.Forms.Timer(this.components);
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.pbBola = new System.Windows.Forms.PictureBox();
            this.pbPlayer1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbBola)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tmBola
            // 
            this.tmBola.Enabled = true;
            this.tmBola.Interval = 1;
            this.tmBola.Tick += new System.EventHandler(this.tmBola_Tick);
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Font = new System.Drawing.Font("ROG Fonts", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1.ForeColor = System.Drawing.Color.Blue;
            this.lblP1.Location = new System.Drawing.Point(145, 9);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(0, 19);
            this.lblP1.TabIndex = 3;
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Font = new System.Drawing.Font("ROG Fonts", 12F, System.Drawing.FontStyle.Bold);
            this.lblP2.ForeColor = System.Drawing.Color.Red;
            this.lblP2.Location = new System.Drawing.Point(278, 9);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(0, 19);
            this.lblP2.TabIndex = 4;
            // 
            // pbBola
            // 
            this.pbBola.BackColor = System.Drawing.Color.Transparent;
            this.pbBola.Image = global::JuegoPingPong.Properties.Resources.chrome1;
            this.pbBola.Location = new System.Drawing.Point(385, 268);
            this.pbBola.Name = "pbBola";
            this.pbBola.Size = new System.Drawing.Size(40, 40);
            this.pbBola.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBola.TabIndex = 2;
            this.pbBola.TabStop = false;
            // 
            // pbPlayer1
            // 
            this.pbPlayer1.BackColor = System.Drawing.Color.Transparent;
            this.pbPlayer1.Image = global::JuegoPingPong.Properties.Resources.ping_pong__1_1;
            this.pbPlayer1.Location = new System.Drawing.Point(0, 248);
            this.pbPlayer1.Name = "pbPlayer1";
            this.pbPlayer1.Size = new System.Drawing.Size(56, 60);
            this.pbPlayer1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlayer1.TabIndex = 1;
            this.pbPlayer1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Location = new System.Drawing.Point(-28, 287);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(492, 10);
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // frmPrimerVentana
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGreen;
            this.ClientSize = new System.Drawing.Size(448, 591);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.pbBola);
            this.Controls.Add(this.pbPlayer1);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPrimerVentana";
            this.Text = "player1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.frmPrimerVentana_KeyDown);
            this.Move += new System.EventHandler(this.frmPrimerVentana_Move);
            ((System.ComponentModel.ISupportInitialize)(this.pbBola)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPlayer1;
        private System.Windows.Forms.PictureBox pbBola;
        private System.Windows.Forms.Timer tmBola;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}