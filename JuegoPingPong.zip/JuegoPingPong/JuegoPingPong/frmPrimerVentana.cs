﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JuegoPingPong
{
    public partial class frmPrimerVentana : Form
    {
        //Variable
        private Point PosicionInicial;
        public frmSegundaVentana VentanaJugador2 { get; set; } //referemcia a la segunda ventana

        public frmPrimerVentana()
        {
            InitializeComponent();
            this.Size = new Size(464, 630);
            this.StartPosition = FormStartPosition.Manual;
            PosicionInicial = new Point(0, 0);
        }


        private void frmPrimerVentana_Move(object sender, EventArgs e)
        {
            if (this.Location != PosicionInicial)
                this.Location = PosicionInicial;

        }

        //raqueta izquierda movimiento con W y S
        private void frmPrimerVentana_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.W)
            {
                pbPlayer1.Top = pbPlayer1.Top - 30;
            }
            if (e.KeyCode == Keys.S)
            {
                pbPlayer1.Top = pbPlayer1.Top + 30;
            }
        }

        public void MoverArriba()
        {
            //raqueta no se salga por arriba del borde
            pbPlayer1.Top = Math.Max(0, pbPlayer1.Top - 30);
        }

        public void MoverAbajo()
        {
            //raqueta no se salga por abajo del borde
            int limiteInferior = this.ClientSize.Height - pbPlayer1.Height;
            pbPlayer1.Top = Math.Min(limiteInferior, pbPlayer1.Top + 30);
        }

        int arriba, abajo, derecha, izquierda;
        int velX = 3;
        int velY = 3;

        int jug1 = 0;
        int jug2 = 0;

        private void colision()
        {
           
            //Elemetno raqueta izquierda
            int raquetaizqarriba = pbPlayer1.Top;
            int raquetaizqderecha = pbPlayer1.Left + pbPlayer1.Width;
            int raquetaizqabajo = pbPlayer1.Top + pbPlayer1.Height;
            int raquetaizqizq = pbPlayer1.Left;

            //Elemetno raqueta derecha
            Rectangle pbPlayer2 = VentanaJugador2.ObtenerRaquetaJugador2();

            int raquetaderarriba = pbPlayer2.Top;
            int raquetaderderecha = pbPlayer2.Left + pbPlayer2.Width;
            int raquetaderabajo = pbPlayer2.Top + pbPlayer2.Height;
            int raquetaderizq = pbPlayer2.Left;

            //Elemetno bola
            int ballUp = pbBola.Top;
            int ballRg = pbBola.Left + pbBola.Width;
            int ballDw = pbBola.Top + pbBola.Height;
            int ballLf = pbBola.Left;

            pbBola.Top = pbBola.Top + velY;
            pbBola.Left = pbBola.Left + velX;

            arriba = 0;
            izquierda = 0;
            abajo = this.Size.Height - pbBola.Height - 36;
            derecha = this.ClientSize.Width - pbBola.Width;

            if (pbBola.Parent == VentanaJugador2)
            {
                Rectangle raqueta2 = VentanaJugador2.ObtenerRaquetaJugador2();

                if (pbBola.Bounds.IntersectsWith(raqueta2) && velX > 0)
                {
                    velX = -Math.Abs(velX);
                }
                // Limite superior
                if (pbBola.Top <= 0)
                {
                    pbBola.Top = 0;
                    velY = Math.Abs(velY);
                }

                if (pbBola.Right >= VentanaJugador2.ClientSize.Width)
                {
                    tmBola.Enabled = false;

                    MessageBox.Show("Ganó el jugador 1");

                    jug1++;
                    reset();

                    return;
                }

                // Limite inferior
                if (pbBola.Bottom >= VentanaJugador2.ClientSize.Height)
                {
                    pbBola.Top = VentanaJugador2.ClientSize.Height - pbBola.Height;
                    velY = -Math.Abs(velY);
                }

                //Regresar a primeraVentana jugador 1
                if (pbBola.Left <= 0 && velX < 0)
                {
                    VentanaJugador2.Controls.Remove(pbBola);
                    this.Controls.Add(pbBola);

                    pbBola.Location = new Point(this.ClientSize.Width - pbBola.Width - 10, Math.Max(0, Math.Min(pbBola.Top,
                    this.ClientSize.Height - pbBola.Height)));

                    velX = -3;
                    pbBola.BringToFront();
                }

                return;
            }

            //Colision raqueta izquierda
            if (ballDw >= raquetaizqarriba && ballUp <= raquetaizqabajo && ballLf <= raquetaizqderecha && ballRg >= raquetaizqizq)
            {
                velX = 3;
            }
            

            //Pelota choco arriba
            if (pbBola.Top <= arriba)
            {
                
                velY = 3;
            }

            //Pelota choco abajo
            if (pbBola.Top >= abajo)
            {
                
                velY = -3;
            }
           

            //Pelota choco izquierda
            if (pbBola.Parent == this && pbBola.Left <= izquierda && velX < 0)  
            {
                tmBola.Enabled = false;
                MessageBox.Show("ganó jugador 2");
                jug2++;
                reset();
            }

            //Pelota choco derecha
            if (pbBola.Right >= this.ClientSize.Width && velX > 0)
            {
                this.Controls.Remove(pbBola);
                velX = 3;
                VentanaJugador2.RecibirPelota(pbBola);

                return;
            }

        }

        private void reset()
        {
            if (pbBola.Parent == VentanaJugador2)
            {
                VentanaJugador2.Controls.Remove(pbBola);
                this.Controls.Add(pbBola);
            }

            pbBola.Location = new Point(396, 268);
            pbBola.BringToFront();

            velX = 3;
            velY = 3;

            //Marcador
            lblP1.Text = jug1.ToString();
            lblP2.Text = jug2.ToString();

            tmBola.Enabled = false;
            MessageBox.Show("Empezar");
            tmBola.Enabled = true;

        }
        public void RecibirPelota(PictureBox pelota)
        {
            this.Controls.Add(pelota);
            pelota.Location = new Point(this.ClientSize.Width - pelota.Width - 10, pelota.Top);
            pelota.BringToFront();
        }
        private void tmBola_Tick(object sender, EventArgs e)
        {
            colision();
        }
    }
}
